#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>

#include "ASTree.hpp"

int main() {

    AST a;

    a(category, "car");
    
}